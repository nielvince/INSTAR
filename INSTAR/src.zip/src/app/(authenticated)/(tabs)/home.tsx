import { ScrollView, Text, View, Image, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { feedPosts, profile } from "@/data/profile";

export default function HomeTab() {
  return (
    <SafeAreaView className="flex-1 bg-[#f5f3ff]">
      <View className="bg-violet-600 px-5 pb-4 pt-6">
        <Text className="text-2xl font-black text-white">hunnypie</Text>
        <Text className="mt-1 text-sm text-violet-100">Your daily inspiration</Text>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: 28 }}
        showsVerticalScrollIndicator={false}
        className="bg-[#f5f3ff]"
      >
        <View className="px-3 pb-4 pt-3">
          {feedPosts.map((post) => (
            <View key={post.id} className="mb-4 overflow-hidden rounded-[22px] bg-white p-3 shadow-sm shadow-slate-200/50">
              <View className="flex-row items-center">
                <Image source={post.avatar} className="h-10 w-10 rounded-full" />
                <View className="ml-3 flex-1">
                  <Text className="text-sm font-bold text-slate-900">
                    {post.name === profile.name ? "Nina Carter" : post.name}
                  </Text>
                  <Text className="text-[11px] text-slate-500">{post.username}</Text>
                </View>
                <Pressable className="rounded-full bg-violet-50 px-2.5 py-1.5">
                  <Text className="text-[11px] font-bold text-violet-600">Follow</Text>
                </Pressable>
              </View>

              <Text className="mt-2 text-[13px] leading-5 text-slate-700">{post.text}</Text>

              <Image
                source={post.image}
                resizeMode="cover"
                className="mt-3 aspect-[4/5] w-full rounded-[18px]"
              />

              <View className="mt-3 flex-row items-center justify-between border-t border-slate-100 pt-3">
                <View className="flex-row items-center">
                  <Text className="mr-1.5 text-base">❤️</Text>
                  <Text className="text-[12px] font-medium text-slate-600">{post.likes}</Text>
                </View>
                <View className="flex-row items-center">
                  <Text className="mr-1.5 text-base">💬</Text>
                  <Text className="text-[12px] font-medium text-slate-600">{post.comments}</Text>
                </View>
                <View className="flex-row items-center">
                  <Text className="mr-1.5 text-base">↗️</Text>
                  <Text className="text-[12px] font-medium text-slate-600">{post.shares}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
